# Supply Chain Watch pipeline (free stack)

Scan supply-chain news → probe the claim → write blog + Facebook post → you approve → publish.

| Stage | What it does | Free tool |
|---|---|---|
| Scan | Google News RSS searches + optional feeds, keyword filter, de-dupe | RSS, no key |
| Probe | Extracts the claim and the company, searches for their track record and past attempts, then answers: is it true? what's missing? tried before? who benefits? | Gemini API free tier |
| Write | Blog post + Facebook post, CTA to Source KE / TenderCville only if the story fits | Gemini |
| Review | Draft lands in `drafts/`. Change `approved: false` to `true` | GitHub web editor (works on a phone) |
| Publish | Moves the post to `docs/_posts` (GitHub Pages) and posts to your Facebook Page | GitHub Pages + Graph API |
| Schedule | Weekdays 07:00 Nairobi, plus a manual "Run workflow" button | GitHub Actions |

## Setup (about 20 minutes)

1. **Repo**: create a GitHub repo, upload this folder's contents.
2. **Gemini key**: get a free key at Google AI Studio. Repo → Settings → Secrets and variables → Actions → add secret `GEMINI_API_KEY`.
3. **Blog**: Settings → Pages → deploy from branch `main`, folder `/docs`. Add a repository *variable* `BLOG_BASE_URL` (e.g. `https://yourname.github.io/repo-name`).
4. **Facebook (optional)**: you need a Page you manage, a Meta developer app, and a Page access token with `pages_manage_posts` (plus `pages_show_list`, `pages_manage_metadata`, `pages_manage_read_engagement` per Meta's Pages API docs). Add secrets `FB_PAGE_ID` and `FB_PAGE_TOKEN`. Without them the blog still publishes.
5. **Edit `config.yaml`**: fill in the TenderCville blurb and both URLs, and check the disclosure wording.
6. **Test**: Actions tab → run the workflow manually. Check `drafts/`.

## Things to know

- **Model names and free limits change.** If runs fail with 404s or 429s, set a repo variable/secret `GEMINI_MODELS` (comma-separated, e.g. `gemini-2.5-flash,gemini-2.5-flash-lite`) to whatever AI Studio currently lists as free. Free-tier prompts may be used by Google to improve its products, so don't feed it anything confidential.
- **The probe is headline-level.** Evidence is news-search headlines, not deep investigation. The model is told to say "not found" rather than guess, and drafts record `full_article_read` and `confidence`. Google News links sometimes don't resolve to full text; then it works from the snippet and says so.
- **Keep `auto_approve: false`.** You are publishing questions about named companies and promoting your own projects. Read each draft, check the cited links, soften anything that reads as an accusation. The disclosure line exists so readers know you have a stake.
- **Facebook page token**: long-lived Page tokens can be obtained via the `/{user-id}/accounts` step; treat it as a password.
- **Try one story on demand:** `python pipeline.py url <link>`. If the site is paywalled or JavaScript-only (Business Daily "PRIME" pages often are), paste the article into a `.txt` file and run `python pipeline.py url <link> article.txt`.
- Run locally: `pip install -r requirements.txt`, set `GEMINI_API_KEY`, then `python pipeline.py scan` (no key needed) or `python pipeline.py run`.
