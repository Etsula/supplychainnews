#!/usr/bin/env python3
"""
Supply-chain pipeline (free stack):
  scan  -> Google News RSS + your feeds, keyword-filtered, de-duplicated
  probe -> LLM checks the claim: true? missing? tried before? who benefits?
  write -> blog post + Facebook post, with a CTA to your own project if relevant
  review-> drafts land in drafts/ ; you flip `approved: true` (or set auto_approve)
  publish-> approved drafts go to docs/_posts (GitHub Pages) and to your FB Page

Usage:  python pipeline.py scan | run | publish | all | url <link> [article.txt]
Env:    GEMINI_API_KEY (required for run)
        FB_PAGE_ID, FB_PAGE_TOKEN, BLOG_BASE_URL (optional, for Facebook)
"""
import hashlib, html, json, os, re, sys, time, urllib.parse
from datetime import date
from pathlib import Path

import feedparser, requests, yaml

try:
    import trafilatura
except ImportError:
    trafilatura = None

ROOT = Path(__file__).parent
CFG = yaml.safe_load((ROOT / "config.yaml").read_text())
STATE, DRAFTS, POSTS = ROOT / "state/seen.json", ROOT / "drafts", ROOT / "docs/_posts"
UA = {"User-Agent": "Mozilla/5.0 (compatible; supply-chain-pipeline)"}


UNVERIFIED_MARKERS = ("REPLACE-ME", "FILL IN", "CONFIRM", "UNCONFIRMED")


def active_projects():
    """Only projects with no pending placeholder/confirmation markers can be promoted."""
    def clean(q):
        blob = " ".join(str(q.get(k, "")) for k in ("name", "blurb", "use_when", "url"))
        return not any(m in blob for m in UNVERIFIED_MARKERS)
    return [q for q in CFG["projects"] if clean(q)]


def project_menu():
    return "\n".join(f"- {q['id']}: {q['name']} - {' '.join(str(q['blurb']).split())} "
                     f"USE WHEN: {' '.join(str(q['use_when']).split())}" for q in active_projects()) or "(none configured)"


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def strip_html(s):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "post"


# ---------------------------------------------------------------- 1. SCAN
def gnews_url(q, days=None):
    q = f"{q} when:{days}d" if days else q
    return ("https://news.google.com/rss/search?q=" + urllib.parse.quote(q)
            + "&hl=en-KE&gl=KE&ceid=KE:en")


def load_seen():
    return set(json.loads(STATE.read_text())) if STATE.exists() else set()


def save_seen(seen):
    STATE.parent.mkdir(exist_ok=True)
    STATE.write_text(json.dumps(sorted(seen)))


def scan():
    seen, items = load_seen(), {}
    urls = list(CFG.get("feeds") or []) + [gnews_url(q, 2) for q in CFG["news_queries"]]
    for u in urls:
        try:
            feed = feedparser.parse(u, request_headers=UA)
        except Exception as ex:
            log("feed failed", u, ex)
            continue
        for e in feed.entries[:30]:
            link, title = e.get("link", ""), e.get("title", "")
            uid = hashlib.sha1((title or link).encode()).hexdigest()[:16]
            if uid in seen or uid in items:
                continue
            summary = strip_html(e.get("summary", ""))
            text = f"{title} {summary}".lower()
            score = sum(k.lower() in text for k in CFG["keywords"])
            if score >= CFG["min_keyword_score"]:
                items[uid] = dict(id=uid, title=title, link=link, summary=summary, score=score)
    ranked = sorted(items.values(), key=lambda x: -x["score"])
    return ranked[: CFG["max_items_per_run"]]


# ---------------------------------------------------------------- LLM
def llm(prompt, system, models=None):
    """Gemini free tier via REST. Tries each model in GEMINI_MODELS until one works."""
    key = os.environ["GEMINI_API_KEY"]
    models = (models or os.environ.get("GEMINI_MODELS", "gemini-2.5-flash,gemini-2.5-flash-lite")).split(",")
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.4, "responseMimeType": "application/json"},
    }
    for m in models:
        for attempt in range(3):
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{m.strip()}:generateContent",
                headers={"x-goog-api-key": key}, json=body, timeout=180)
            if r.status_code == 200:
                parts = r.json()["candidates"][0]["content"]["parts"]
                txt = "".join(p.get("text", "") for p in parts if not p.get("thought"))
                txt = re.sub(r"^```(?:json)?|```$", "", txt.strip()).strip()
                time.sleep(CFG["llm_pause_seconds"])
                return json.loads(txt)
            log(f"{m} -> HTTP {r.status_code}: {r.text[:200]}")
            if r.status_code == 429:
                time.sleep(25 * (attempt + 1))
            elif r.status_code in (400, 404):
                break  # bad/retired model name: try the next one
            else:
                time.sleep(5)
    raise RuntimeError("all models failed (quota or model names) - check GEMINI_MODELS")


SYSTEM = (
    "You are a sceptical, fair-minded supply-chain analyst writing for Kenyan suppliers, SMEs and "
    "procurement people. Rules: (1) Use ONLY the article text and the numbered evidence given; never "
    "invent facts, figures, names, dates or quotes. (2) If something is not in the evidence, say "
    "'not found' or 'unverified'. (3) Challenge claims, incentives and framing, never people's "
    "character; do not state as fact that anyone is lying or acting in bad faith - raise it as a "
    "question. (4) Cite evidence by its E-number. (5) Plain, direct English."
)


# ---------------------------------------------------------------- 2. PROBE
BLOCKED_MARKERS = ("couldn't load the article", "enable javascript", "subscribe to continue",
                   "subscribers only", "your subscription ends", "sign in to read")


def looks_blocked(text):
    t = text.lower()
    return any(m in t for m in BLOCKED_MARKERS)


def fetch_text(url, limit=7000):
    try:
        r = requests.get(url, headers=UA, timeout=20, allow_redirects=True)
        t = (trafilatura.extract(r.text) if trafilatura else strip_html(r.text)) or ""
        return t[:limit]
    except Exception as ex:
        log("fetch failed", url, ex)
        return ""


def news_search(q, n=6):
    feed = feedparser.parse(gnews_url(q), request_headers=UA)
    return [dict(title=e.get("title", ""), src=(e.get("source") or {}).get("title", ""),
                 date=e.get("published", "")[:16], link=e.get("link", "")) for e in feed.entries[:n]]


def probe(item):
    art = item.get("text") or fetch_text(item["link"])
    full = len(art) > 800 and not looks_blocked(art)
    if not full:
        art = ""
    source_text = art if full else f"{item['title']}. {item['summary']}"

    ext = llm(
        f"ARTICLE TITLE: {item['title']}\nARTICLE TEXT:\n{source_text}\n\n"
        "Return JSON with keys: relevant (true only if genuinely about supply chains, procurement, "
        "logistics or supplier finance in or affecting Kenya/Africa), topic (short), claim (the central "
        "claim or problem being pushed, 1-2 sentences), entities (up to 2 companies/organisations "
        "behind the initiative or claim, [] if none), precedent_queries (up to 2 short news-search "
        "queries to find whether similar initiatives were tried before in Kenya/Africa and how they went).",
        SYSTEM)
    if not ext.get("relevant"):
        return None, "not relevant"

    queries = []
    for ent in (ext.get("entities") or [])[:2]:
        queries += [f'"{ent}" Kenya', f'"{ent}" lawsuit OR default OR complaint OR collapsed OR failed']
    queries += (ext.get("precedent_queries") or [])[:2]
    evidence, lines = [], []
    for q in queries:
        for hit in news_search(q):
            if hit["link"] not in [e["link"] for e in evidence]:
                evidence.append(hit)
    for i, e in enumerate(evidence[:20], 1):
        lines.append(f"E{i} | {e['date']} | {e['src']} | {e['title']} | {e['link']}")
    evidence = evidence[:20]

    analysis = llm(
        f"ARTICLE TITLE: {item['title']}\nARTICLE URL: {item['link']}\n"
        f"FULL ARTICLE RETRIEVED: {full} (if False, you only have the headline/snippet - say so)\n"
        f"ARTICLE TEXT:\n{source_text}\n\nEXTRACTED CLAIM: {ext.get('claim')}\n"
        f"ENTITIES: {ext.get('entities')}\n\nEVIDENCE (headline-level search hits):\n"
        + ("\n".join(lines) or "none found") + "\n\n"
        "Probe this story. Return JSON with keys: "
        "claim; who_is_behind (what the article/evidence says about the company - what have they done "
        "before, or 'not found'); is_it_true (object: verdict = supported|partly supported|unsupported|"
        "unclear, reasoning, evidence_for [list], evidence_against [list]); "
        "root_cause_check (is the stated problem, e.g. lack of capital, the real problem, or is it access, "
        "trust, late payment, paperwork, market linkage? Is this a familiar problem repackaged? Answer as "
        "questions/possibilities, not accusations); whats_missing [list of what the story does not say]; "
        "precedent (has this been tried before, and what happened, per evidence only); "
        "who_benefits [list of parties and how]; questions_to_ask [4-6 questions for the company]; "
        "project_fit (pick ONE id from this menu only if the story genuinely fits its USE WHEN; a forced "
        "or tenuous fit must be 'none'):\n" + project_menu() + "\n"
        "confidence (low|medium|high); publishable (false if evidence is too thin to say "
        "anything useful or the story is off-topic).",
        SYSTEM)
    analysis["_evidence"] = evidence
    analysis["_full_article"] = full
    return analysis, "ok"


# ---------------------------------------------------------------- 3. WRITE
def write(item, a):
    project = next((q for q in active_projects() if q["id"] == a.get("project_fit")), None)
    cta = (f"CTA PROJECT: {project['name']} - {project['blurb']} URL: {project['url']}\n"
           "Add a short, honest, non-salesy call to action near the end, only where it follows naturally."
           if project else "No CTA project fits this story; end with a useful takeaway instead.")
    ev = "\n".join(f"E{i} | {e['src']} | {e['title']} | {e['link']}" for i, e in enumerate(a["_evidence"], 1))
    out = llm(
        f"ANALYSIS (JSON):\n{json.dumps({k: v for k, v in a.items() if not k.startswith('_')}, indent=1)}\n\n"
        f"ORIGINAL STORY: {item['title']} - {item['link']}\nEVIDENCE LIST:\n{ev}\n\n{cta}\n\n"
        "Write two pieces. Return JSON with keys: title (specific, no clickbait, no company accusations), "
        "blog_markdown (450-750 words, ## headings: What is being claimed / What we checked / What the "
        "story leaves out / Has this been tried before / Who benefits / What to ask next / final takeaway "
        "with CTA if any; only cite sources that are in the EVIDENCE LIST or the original story, as "
        "markdown links; state uncertainty plainly; questions not accusations), "
        "facebook_post (max 900 characters, strong first line, 3-4 short points, ends with a CTA line, "
        "at most 3 hashtags, NO URL - it is attached separately).",
        SYSTEM)
    today = date.today().isoformat()
    slug = slugify(out["title"])
    body = out["blog_markdown"].strip() + "\n\n---\n"
    if CFG.get("ecosystem_footer") and active_projects():
        body += "*Also from us: " + " | ".join(f"[{q['name']}]({q['url']})" for q in active_projects()) + "*\n\n"
    body += "*" + CFG["disclosure"].strip() + "*\n"
    meta = dict(layout="post", title=out["title"], date=today, approved=bool(CFG["auto_approve"]),
                verdict=(a.get("is_it_true") or {}).get("verdict"), confidence=a.get("confidence"),
                full_article_read=a["_full_article"], source_url=item["link"],
                facebook=out["facebook_post"].strip(), fb_post_id=None)
    DRAFTS.mkdir(exist_ok=True)
    path = DRAFTS / f"{today}-{slug}.md"
    write_post(path, meta, body)
    return path


def read_post(p):
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", p.read_text(), re.S)
    return yaml.safe_load(m.group(1)), m.group(2)


def write_post(p, meta, body):
    p.write_text("---\n" + yaml.safe_dump(meta, allow_unicode=True, sort_keys=False) + "---\n" + body)


# ---------------------------------------------------------------- 4. PUBLISH
def fb_post(message, link):
    v = os.environ.get("FB_GRAPH_VERSION", "v25.0")
    r = requests.post(f"https://graph.facebook.com/{v}/{os.environ['FB_PAGE_ID']}/feed",
                      data={"message": message, "link": link, "access_token": os.environ["FB_PAGE_TOKEN"]},
                      timeout=30)
    if not r.ok:
        raise RuntimeError(f"Facebook error {r.status_code}: {r.text[:300]}")
    return r.json()["id"]


def publish():
    POSTS.mkdir(parents=True, exist_ok=True)
    base = os.environ.get("BLOG_BASE_URL", "").rstrip("/")
    can_fb = all(os.environ.get(k) for k in ("FB_PAGE_ID", "FB_PAGE_TOKEN")) and base
    for p in sorted(DRAFTS.glob("*.md")):
        meta, body = read_post(p)
        if not meta.get("approved"):
            continue
        y, m, d, slug = p.name[:4], p.name[5:7], p.name[8:10], p.name[11:-3]
        dest = POSTS / p.name
        write_post(dest, meta, body)
        p.unlink()
        log("published to blog:", dest.name)
        if can_fb and not meta.get("fb_post_id"):
            try:
                meta["fb_post_id"] = fb_post(meta["facebook"], f"{base}/{y}/{m}/{d}/{slug}.html")
                write_post(dest, meta, body)
                log("posted to Facebook:", meta["fb_post_id"])
            except Exception as ex:
                log("Facebook post failed (blog is still live):", ex)


# ---------------------------------------------------------------- ONE URL
def probe_url(link, textfile=None):
    """python pipeline.py url <link> [article.txt]  - use the txt when the site is paywalled/JS-only."""
    title = link
    try:
        m = re.search(r"<title[^>]*>(.*?)</title>", requests.get(link, headers=UA, timeout=20).text, re.S | re.I)
        title = strip_html(m.group(1)) if m else link
    except Exception as ex:
        log("title fetch failed", ex)
    item = dict(id=hashlib.sha1(link.encode()).hexdigest()[:16], title=title, link=link, summary="", score=0)
    if textfile:
        item["text"] = Path(textfile).read_text()[:7000]
    analysis, status = probe(item)
    if analysis and analysis.get("publishable"):
        log("draft:", write(item, analysis).name)
    else:
        log("no draft:", status if not analysis else "evidence too thin")


# ---------------------------------------------------------------- RUN
def run():
    seen = load_seen()
    for item in scan():
        log("->", item["title"])
        try:
            analysis, status = probe(item)
            if analysis and analysis.get("publishable"):
                log("   draft:", write(item, analysis).name)
            else:
                log("   skipped:", status if not analysis else "evidence too thin")
            seen.add(item["id"])  # only mark seen after a clean attempt (quota errors retry next run)
        except Exception as ex:
            log("   error, will retry next run:", ex)
    save_seen(seen)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd == "scan":
        for it in scan():
            print(it["score"], it["title"], it["link"])
    elif cmd == "run":
        run()
    elif cmd == "publish":
        publish()
    elif cmd == "url":
        probe_url(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
    else:
        run()
        publish()
